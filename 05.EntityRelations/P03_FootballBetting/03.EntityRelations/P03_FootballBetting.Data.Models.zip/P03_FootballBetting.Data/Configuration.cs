﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    internal class Configuration
    {
        internal const string ConnectionString =
            @"Server=OKMUHB77\SQLEXPRESS;Database=FootballBetting;Integrated Security=True";
    }
}
