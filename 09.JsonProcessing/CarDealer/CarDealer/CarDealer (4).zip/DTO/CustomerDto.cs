﻿using System;

namespace CarDealer.DTO
{
    internal class CustomerDto
    {
        public string Name { get; set; }

        public string BirthDate { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}