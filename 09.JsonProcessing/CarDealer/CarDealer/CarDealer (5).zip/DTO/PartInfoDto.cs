﻿using CarDealer.Models;

namespace CarDealer.DTO
{
    internal class PartInfoDto
    {
        public string Name { get; set; }

        public string Price { get; set; }
    }
}
