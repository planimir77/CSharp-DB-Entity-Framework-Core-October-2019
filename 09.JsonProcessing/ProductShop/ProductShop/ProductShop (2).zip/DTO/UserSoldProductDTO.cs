﻿
using System.Linq;

namespace ProductShop.DTO
{
    using System.Collections.Generic;
    using Newtonsoft.Json;
    internal class UserSoldProductDTO
    {
        [JsonProperty(PropertyName = "count")] 
        public int Count => this.Products.Count();//{ get; set; }

        [JsonProperty(PropertyName = "products")]
        public IEnumerable<ProductNameAndPriceDTO> Products { get; set; }
    }
}